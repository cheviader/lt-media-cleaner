<?php
defined( 'ABSPATH' ) || exit;

class LT_Media_Cleaner_Importer {
    public static function init() {
        add_action( 'lt_mc_import_external_images_for_post', [ __CLASS__, 'import_external_images' ], 10, 1 );
    }

    public static function import_external_images( $post_id ) {
        set_time_limit(0);
        
        $post = get_post( $post_id );
        if ( ! $post ) return;

        // Chercher toutes les images .files.wordpress.com dans src ou href
        if ( ! preg_match_all( '/["\'](https?:\/\/[^"\']+\.files\.wordpress\.com\/[^"\']+\.(?:jpg|jpeg|png|gif|webp)[^"\']*)["\']/i', $post->post_content, $matches ) ) {
            return;
        }

        // On élimine les doublons au cas où une image est dans un href et un src
        $urls_to_import = array_unique( $matches[1] );

        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $content_updated = false;

        // Filtre pour forcer l'upload_dir à correspondre à la date de l'article
        $upload_dir_filter = function( $dirs ) use ( $post ) {
            $time = strtotime( $post->post_date );
            $subdir = '/' . date( 'Y', $time ) . '/' . date( 'm', $time );
            $dirs['subdir'] = $subdir;
            $dirs['path']   = $dirs['basedir'] . $subdir;
            $dirs['url']    = $dirs['baseurl'] . $subdir;
            return $dirs;
        };

        add_filter( 'upload_dir', $upload_dir_filter );

        foreach ( $urls_to_import as $full_url ) {
            // L'URL de téléchargement ne doit pas avoir de paramètres (ex: ?w=300)
            $clean_url = strtok( $full_url, '?' );

            // Si le fichier a déjà été remplacé dans une passe précédente
            if ( strpos( $post->post_content, $full_url ) === false ) continue;

            $attachment_id = media_sideload_image( $clean_url, $post_id, null, 'id' );

            if ( ! is_wp_error( $attachment_id ) ) {
                // Rétro-dater l'attachement pour garder l'intégrité de la bibliothèque
                wp_update_post([
                    'ID'            => $attachment_id,
                    'post_date'     => $post->post_date,
                    'post_date_gmt' => $post->post_date_gmt
                ]);

                $new_local_url = wp_get_attachment_url( $attachment_id );
                if ( $new_local_url ) {
                    // 1. Ajouter l'image originale fraîchement téléchargée au ZIP de backup
                    $file_path = get_attached_file( $attachment_id );
                    $year = date( 'Y', strtotime( $post->post_date ) );
                    $month = date( 'm', strtotime( $post->post_date ) );
                    $uploads = wp_get_upload_dir();
                    $zip_path = $uploads['basedir'] . '/lt-media-backups/' . $year . '-' . $month . '.zip';
                    
                    if ( file_exists( $zip_path ) && class_exists('ZipArchive') ) {
                        $zip = new ZipArchive();
                        if ( $zip->open( $zip_path ) === true ) {
                            $month_dir = $uploads['basedir'] . '/' . $year . '/' . $month;
                            $relative_path = substr( $file_path, strlen( $month_dir ) + 1 );
                            $zip->addFile( $file_path, $relative_path );
                            $zip->close();
                            error_log( "LT_MC Importer: Fichier $relative_path ajouté au backup ZIP." );
                        }
                    }

                    // 2. Remplacement strict de l'URL exacte wp.com par l'URL locale toute fraîche
                    $post->post_content = str_replace( $full_url, $new_local_url, $post->post_content );
                    $content_updated = true;

                    // 3. Planifier l'image locale pour le WebP et S3
                    as_enqueue_async_action( 'lt_mc_process_image', [ 'attachment_id' => $attachment_id ], 'lt_media_cleaner_images' );
                    
                    error_log( "LT_MC Importer: Succès $clean_url -> $new_local_url" );
                }
            } else {
                error_log( "LT_MC Importer: Echec $clean_url : " . $attachment_id->get_error_message() );
            }
        }

        remove_filter( 'upload_dir', $upload_dir_filter );

        // Sauvegarde silencieuse en BDD
        if ( $content_updated ) {
            global $wpdb;
            $wpdb->update( $wpdb->posts, [ 'post_content' => $post->post_content ], [ 'ID' => $post_id ] );
        }
    }
}
